<a href="https://gulpjs.com/" target="_blank"><img src="https://img.shields.io/badge/-gulp-eb4a4b.svg?logo=data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAAAYAAAAOCAMAAAA7QZ0XAAAABlBMVEUAAAD%2F%2F%2F%2Bl2Z%2FdAAAAAXRSTlMAQObYZgAAABdJREFUeAFjAAFGRjSSEQzwUgwQkjAFAAtaAD0Ls2nMAAAAAElFTkSuQmCC" alt="Built with Gulp" height="18"></a> 
<a href="https://badge.fury.io/js/formstone"><img src="https://badge.fury.io/js/formstone.svg" alt="npm version" height="18"></a> 
<a href="https://travis-ci.org/Formstone/Formstone"><img src="https://travis-ci.org/Formstone/Formstone.svg?branch=master" alt="Travis CI" height="18"></a> 
<a href="https://david-dm.org/formstone/formstone"><img src="https://david-dm.org/formstone/formstone.svg" alt="David DM" height="18"></a> 
<a href="https://david-dm.org/formstone/formstone#info=devDependencies&view=table"><img src="https://david-dm.org/formstone/formstone/dev-status.svg" alt="David DM" height="18"></a> 

# Formstone 

Library of modular front end components. 

[Documentation](docs/README.md) <br>[Changelog](CHANGELOG.md) <br>[Licensing](https://formstone.it/license) 

### License 

Available under the GNU GPL v3 for all open source applications. <br>A commercial license is required for all commercial applications.