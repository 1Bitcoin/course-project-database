<?php
  // Only output on full page loads
  if (!$isASAP) {
?>
          </div>

          <div class="copyright">&copy; <?=date('Y')?></div>

        </div>
      </div>
    </div>

  </body>
</html>
<?php
  }
  // END: Only output on full page loads