{"template":"component.html","title":"Core","demo":"[No Demo]","asset_root":"../","year":2021}

 #Core Demo
<p class="back_link"><a href="https://formstone.it/components/core">View Documentation</a></p>