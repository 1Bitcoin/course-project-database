{"template":"theme.html","title":"Light","site_root":"../","asset_root":"../../","component_root":"../../components/"}

# Light

<script>
  $(function() {
    $(".js-demo_carousel").carousel();
    $(".js-demo_checkbox").checkbox();
    $(".js-demo_dropdown").dropdown();
    
    $(".js-demo_number").number();
    
    $(".js-demo_pagination").pagination();
    
    $(".js-demo_range").range();
    $(".js-demo_scrollbar").scrollbar();
    
    $(".js-demo_tabs").tabs();
    $(".js-demo_tooltip").tooltip();
    $(".js-demo_upload").upload();
  });
</script>